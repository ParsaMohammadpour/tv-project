package Model.Request;
public enum Status {ACCEPTED,REJECTED,PENDING
}
